Please see the documents directory "docs" and read through the file
"README-FIRST-RAMS.pdf" to get background information on RAMS. This will
help guide you through setting up software needed to run RAMS, tell you
how to run RAMS for different applications, and provide some troubleshooting
information. There are also more detailed documents for the various
aspects of the RAMS model.
