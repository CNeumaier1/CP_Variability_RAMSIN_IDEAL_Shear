# RAMS
[![DOI](https://zenodo.org/badge/307815774.svg)](https://zenodo.org/badge/latestdoi/307815774)

RAMS model source code. To see full documentation, go to the [van den Heever group website](https://vandenheever.atmos.colostate.edu/vdhpage/rams/rams_docs.php). 